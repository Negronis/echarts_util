<template>
    <div>
        <div style="height:300px;width:100%;position:relative">
            <div ref="lines" style="height:300px;width:100%;"></div>
        </div>
        <div style="position: absolute;right:10px;bottom:10px;font-size: 20px;">危急值处理时间(本月)</div>
    </div>
</template>

<script>
import Echartsinit from '@/components/adminDataEcharts/echarts_init';
import option from './index';
export default {
    props: [
        'title', 'data', 'reff'
    ],
    data() {
        return {
            charts: null,
        }
    },
    methods: {
        chartInit(chartData, y) {
            let color = ['rgba(45,183,245 , .8)', 'rgba(255,151,121 , .8)', 'rgba(48, 236, 166 , .8)' , 'rgba(247,178,0,.8)'];
            let arrName = [];
            let arrValue = [];
            let sum = 0;
            let pieSeries = [],
                lineYAxis = [];
            // 数据处理
            chartData.forEach((v, i) => {
                arrName.push(v.name);
                arrValue.push(v.value);
                sum = sum + v.value;
            })

            // 图表option整理
            chartData.forEach((v, i) => {
                pieSeries.push({
                    name: '危机处理时间',
                    type: 'pie',
                    clockWise: false,
                    hoverAnimation: false,
                    radius: [(65 - i * 15) * 1.5 + '%', (57 - i * 15) * 1.5 + '%'],
                    center: ["40%", "50%"],
                    label: {
                        show: false
                    },
                    itemStyle: {
                        normal: {
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 1,
                                x2: 0,
                                y2: 0,
                                colorStops: [{
                                    offset: 0,
                                    color: color[i].replace('.8', '1'), // 0% 处的颜色
                                },
                                {
                                    color: color[i].replace('.8', '0.5'), // 100% 处的颜色
                                    offset: 1,
                                },
                                ],
                                globalCoord: false, // 缺省为 false
                            }, //渐变颜色
                            shadowColor: color[i],
                            shadowBlur: 20
                        },
                    },
                    data: [{
                        value: v.value,
                        name: v.name
                    }, {
                        value: sum - v.value,
                        name: '',
                        itemStyle: {
                            color: "rgba(0,0,0,0)"
                        }
                    }]
                });
                pieSeries.push({
                    name: '',
                    type: 'pie',
                    silent: true,
                    z: 1,
                    clockWise: false, //顺时加载
                    hoverAnimation: false, //鼠标移入变大
                    radius: [(65 - i * 15) * 1.5 + '%', (57 - i * 15) * 1.5 + '%'],
                    center: ["40%", "50%"],
                    label: {
                        show: false
                    },
                    data: [{
                        value: 7.5,
                        itemStyle: {
                            color: "rgba(255,255,255,.3)"
                        }
                    }, {
                        value: 2.5,
                        name: '',
                        itemStyle: {
                            color: "rgba(0,0,0,0)"
                        }
                    }]
                });
                v.percent = (v.value / sum * 100).toFixed(1) + "%";
                lineYAxis.push({
                    value: i,
                    textStyle: {
                        rich: {
                            circle: {
                                color: color[i],
                                padding: [0, 5], 
                            }
                        }
                    }
                });
            })
            return {
                y: lineYAxis,
                d: pieSeries
            }
        },
        req(type, data) {
            if (!data) {
                return
            }
            data['d'].forEach(e => {
                e['unit'] = '个'
            })
            let o = this.chartInit(data['d'], data['x'])
            option['yAxis'][0]['axisLabel']['formatter'] = function (params) {
                let item = data['d'][params];
                return '{line|}{circle|●}{name|' + item.name + '}{bd|}{value|' + item.value + '}{unit|个}{percent|' + item.percent + '}'
            }; 
            option['series'] = o['d']
            option['yAxis'][0]['data'] = o['y']
            if (type) {
                let that = this; 
                this.$nextTick(() => {
                    that.charts = Echartsinit.init(
                        that.$refs.lines,
                        option
                    );
                });
                return
            }
            this.charts.setOption(option)
        },
        init(type, data) {
            if (type) {
                this.req('init', data)
            } else {
                this.req('', data)
            }
        }
    },
}
</script>

<style></style>
 let dashedPic = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAM8AAAAOBAMAAAB6G1V9AAAAD1BMVEX////Kysrk5OTj4+TJycoJ0iFPAAAAG0lEQVQ4y2MYBaNgGAMTQQVFOiABhlEwCugOAMqzCykGOeENAAAAAElFTkSuQmCC';
 let color = ['rgba(45,183,245 , .8)', 'rgba(255,151,121 , .8)', 'rgba(48, 236, 166 , .8)'];
 let option = {
     backgroundColor: 'transparent',
     color: color,
     grid: {
         top: '2%',
         bottom: '68%',
         left: "40%",
         containLabel: false
     },
     yAxis: [{
         type: 'category',
         inverse: true,
         axisLine: {
             show: false
         },
         axisTick: {
             show: false
         },
         axisLabel: {
             formatter: '',
             interval: 0,
             inside: true,
             textStyle: {
                 color: "#fff",
                 fontSize: 20,
                 rich: {
                     line: {
                         width: 100,
                         height: 0,
                         backgroundColor: {
                             image: dashedPic
                         }
                     },
                     name: {
                         color: '#fff',
                         width: 120,
                         fontSize: 18,
                     },
                     bd: {
                         color: '#fff',
                         padding: [0, 5],
                         fontSize: 18,
                     },
                     percent: {
                         color: '#fff',
                         fontSize: 18,
                         padding: [0, 20, 0, 20]
                     },
                     value: {
                         color: 'rgba(45,183,245 , 1)',
                         fontSize: 18,
                         fontWeight: 'bold', 
                     },
                     unit:{
                        color:'rgba(45,183,245 , 1)',
                        fontSize:18,
                        fontWeight:"bold"
                     },
                 }
             },
             show: true
         },
         data: []
     }],
     xAxis: [{
         show: false
     }],
     series: []
 };
 export default option